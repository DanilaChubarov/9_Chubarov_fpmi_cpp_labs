#pragma once
#include "Rook.h"
#include "Bishop.h"
class Queen :  public Bishop, public Rook
{
public:
    std::string GetInfo() const override
    {
        char c = static_cast<char>('a' + x_ - 1);
        char c2 = static_cast<char>('0' + y_);
        std::string str = "Q";
        str = str + c + c2;
        return str;
    }
    bool CanMove(uint16_t x, uint16_t y) const override
    {
        return (Bishop::CanMove(x, y) || Rook::CanMove(x, y));
    }
    void Move(uint16_t x, uint16_t y) override
    {
        if (!CanMove(x, y))
        {
            throw std::invalid_argument("Error: could not move this piece");
            return;
        }
        x_ = x;
        y_ = y;
    }
    Queen(uint16_t x, uint16_t y, Color c) : ChessPiece(x, y, c), Bishop(x,y,c), Rook(x,y,c) {}
    ~Queen() override = default;
    Queen& operator=(const Queen& rhs)
    {
        ChessPiece::operator=(rhs);
    }
    Queen(const Queen& other) noexcept : ChessPiece(other), Bishop(other), Rook(other)
    {
    }
    Queen(Queen&& other) noexcept : ChessPiece(other), Bishop(other), Rook (other) {}
    Queen& operator=(Queen&& rhs)
    {
        ChessPiece::operator=(rhs);
    }


};

