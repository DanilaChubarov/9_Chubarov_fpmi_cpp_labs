#pragma once
#include "ChessPiece.h"
class Bishop : public virtual ChessPiece
{
public:
    std::string GetInfo() const override
    {
        char c = static_cast<char>('a' + x_ - 1);
        char c2 = static_cast<char>('0' + y_);
        std::string str = "B";
        str = str + c + c2;
        return str;
    }
    bool CanMove(uint16_t x, uint16_t y) const override
    {
        if (abs(x_ - x) == abs(y_ - y))
        {
            return true;
        }
        return false;
    }
    void Move(uint16_t x, uint16_t y) override
    {
        if (!CanMove(x, y))
        {
            throw std::invalid_argument("Error: could not move this piece");
            return;
        }
        x_ = x;
        y_ = y;
    }
    Bishop(uint16_t x, uint16_t y, Color c) : ChessPiece(x, y, c) {}
    ~Bishop() override = default;
    Bishop& operator=(const Bishop& rhs)
    {
        ChessPiece::operator=(rhs);
    }
    Bishop(const Bishop& other) noexcept : ChessPiece(other)
    {
    }
    Bishop(Bishop&& other) noexcept : ChessPiece(other) {}
    Bishop& operator=( Bishop&& rhs)
    {
        ChessPiece::operator=(rhs);
    }


 
};

