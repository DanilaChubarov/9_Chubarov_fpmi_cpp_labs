#pragma once
#include "ChessPiece.h"
#include "Bishop.h"
#include "Rook.h"
class Rook : public virtual ChessPiece
{
public:
    std::string GetInfo() const override
    {
        char c = static_cast<char>('a' + x_ - 1);
        char c2 = static_cast<char>('0' + y_);
        std::string str="R";
        str = str + c + c2;
        return str;
    }
    bool CanMove(uint16_t x, uint16_t y) const override
    {
        if (x_==x || y_==y)
        {
            return true;
        }
        return false;
    }
    void Move(uint16_t x, uint16_t y) override
    {
        if (!CanMove(x, y))
        {
            throw std::invalid_argument("Error: could not move this piece");
            return;
        }
        x_ = x;
        y_ = y;
    }
    Rook(uint16_t x, uint16_t y, Color c) : ChessPiece(x, y, c) {}
    ~Rook() override = default;
    Rook& operator=(const Rook& rhs)
    {
        ChessPiece::operator=(rhs);
    }
    Rook(const Rook& other) : ChessPiece(other)
    {
    }
    Rook(Rook&& other) : ChessPiece(other) {}
    Rook& operator=(Rook&& rhs) noexcept
    {
        ChessPiece::operator=(rhs);
    }
   
};

