#include "MoveLogger.h"
int MoveLogger:: next_id_ = 1;
