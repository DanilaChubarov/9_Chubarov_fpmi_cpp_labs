#pragma once
#include <string>
#include <stdexcept>
enum class Color{white, black};
class ChessPiece
{
	protected:
		Color color_;
		uint16_t x_;
		uint16_t y_;
public:
	virtual std::string GetInfo() const = 0;
	virtual bool CanMove(uint16_t x, uint16_t y) const = 0;
	virtual void Move(uint16_t x, uint16_t y) = 0;
    
	ChessPiece(uint16_t x, uint16_t y, Color c) : x_(x), y_(y), color_(c) {}
	virtual ~ChessPiece() = default;
	ChessPiece(const ChessPiece& other) : x_(other.x_), y_(other.y_), color_(other.color_) {}
	ChessPiece& operator=(const ChessPiece& rhs)
	{
		if (this == &rhs)
		{
			return *this;
		}
		x_ = rhs.x_;
		y_ = rhs.y_;
		color_ = rhs.color_;
	}
	ChessPiece(ChessPiece&& other) noexcept : x_(other.x_), y_(other.y_), color_(other.color_)
	{
		other.x_ = 0;
		other.y_ = 0;

	}
	ChessPiece& operator=( ChessPiece&& rhs) noexcept
	{
		if (this == &rhs)
		{
			return *this;
		}
		x_ = rhs.x_;
		y_ = rhs.y_;
		color_ = rhs.color_;
		rhs.x_ = 0;
		rhs.y_ = 0;
	}
	Color GetColor() const
	{
		return color_;
	}
	std::string GetPositionInfo() const 
	{
		char c = static_cast<char>('a' + x_ - 1);
		char c2 = static_cast<char>('0' + y_);
		std::string str = { c };
		str += c2;
		return str;
	}


	
};

