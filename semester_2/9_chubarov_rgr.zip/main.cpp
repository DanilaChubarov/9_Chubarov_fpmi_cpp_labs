#include <iostream>
#include "Queen.h"
#include"MoveLogger.h"
int main()
{
	Rook rok(2, 3, Color::white);
	Queen q(8, 8, Color::black);
	std::cout << rok.GetInfo();
	MoveLogger game1;
	game1.AddMove(rok, 2, 7);
	game1.AddMove(q, 4, 4);
	MoveLogger game2;
	game2.AddMove(rok, 5, 7);
	game2.AddMove(q, 1, 8);

	return 0;
}