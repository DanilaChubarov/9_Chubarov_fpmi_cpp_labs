#pragma once
#include"Queen.h"
#include <vector>
#include<fstream>
class MoveLogger
{
private:
	static int next_id_;
     int id_;
	std::vector<std::string> moves_{};
public:
	void AddMove(ChessPiece& piece, uint16_t x, uint16_t y)
	{
		std::string str;
		if (piece.GetColor() == Color::white)
		{
			str = "white: ";
		}
		else
		{
			str = "black: ";
		}
		str += piece.GetInfo();
		str += " - ";
		try {
			piece.Move(x, y);
		}
		catch (const std::exception e)
		{
			str = "";
			str = e.what();
			moves_.push_back(str);
			return;
		}
		str += piece.GetPositionInfo();
		moves_.push_back(str);
	}
	MoveLogger() :id_(next_id_++) {}
	MoveLogger(const MoveLogger& other) = delete;
	MoveLogger& operator= (const MoveLogger& rhs) = delete;
	MoveLogger(MoveLogger&& other) noexcept : id_(next_id_++), moves_(std::move(other.moves_))
	{
		other.moves_.clear();
	}
	MoveLogger& operator= (MoveLogger&& rhs) noexcept 
	{
		if (this == &rhs)
		{
			return *this;
		}
		id_ = next_id_++;
		moves_ = std::move(rhs.moves_);
	}
	~MoveLogger()
	{
		std::string path = "game_";
		path += std::to_string(id_);
		path += "_log.txt";
		std::ofstream out(path);
		if (moves_.empty())
		{
			out << "Game has no moves\n";
		}
		for (size_t i = 0; i < moves_.size(); ++i)
		{
			out << i+1 << ". " << moves_[i] << std::endl;
		}
		moves_.clear();
		moves_.shrink_to_fit();
	}




};

